from clima import montar_clima_mensal_para
from configuracao import ARQUIVO_PRODES_MANUAL, PASTA_DADOS_TRATADOS
from desmatamento import carregar_desmatamento_anual_para
from desmatamento_shapefile import calcular_desmatamento_por_municipio
from enso import montar_enso_mensal
from focos import baixar_arquivos_focos, contar_focos_mensais_por_municipio
from montagem import montar_base_anual_prodes, montar_base_mensal_completa, recortar_base_mensal_analise
from municipios import baixar_malha_municipios_para, carregar_municipios_para

CORRECOES_NOMES_MUNICIPIOS = {}


def executar():
    PASTA_DADOS_TRATADOS.mkdir(parents=True, exist_ok=True)
    tabela_municipios = carregar_municipios_para()
    print(f"Municipios do Para carregados: {len(tabela_municipios)}")
    baixar_malha_municipios_para()

    arquivos_focos = baixar_arquivos_focos()
    focos_mensais = contar_focos_mensais_por_municipio(arquivos_focos, tabela_municipios, CORRECOES_NOMES_MUNICIPIOS)
    enso_mensal = montar_enso_mensal()
    clima_mensal = montar_clima_mensal_para(tabela_municipios)

    base_mensal_completa = montar_base_mensal_completa(tabela_municipios, focos_mensais, clima_mensal, enso_mensal)
    recortar_base_mensal_analise(base_mensal_completa).to_csv(PASTA_DADOS_TRATADOS / "base_mensal.csv", index=False)
    print("Base mensal salva.")

    if not ARQUIVO_PRODES_MANUAL.exists():
        calcular_desmatamento_por_municipio()
    desmatamento_anual = carregar_desmatamento_anual_para()
    if desmatamento_anual is None:
        print("Desmatamento nao encontrado: coloque o zip do shapefile do PRODES em dados/brutos/prodes_shapefile/. Base anual nao gerada.")
        return
    montar_base_anual_prodes(base_mensal_completa, desmatamento_anual).to_csv(
        PASTA_DADOS_TRATADOS / "base_anual_prodes.csv", index=False
    )
    print("Base anual salva.")


if __name__ == "__main__":
    executar()
