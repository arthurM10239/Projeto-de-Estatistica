import time
import unicodedata

import requests


def normalizar_nome(texto):
    sem_acento = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode("ascii")
    return " ".join(sem_acento.upper().replace("-", " ").replace("'", " ").split())


def requisitar_com_tentativas(url, parametros=None, tentativas=4, espera_segundos=5, **opcoes):
    for numero_tentativa in range(1, tentativas + 1):
        try:
            resposta = requests.get(url, params=parametros, timeout=opcoes.pop("timeout", 120), **opcoes)
            if resposta.status_code == 404:
                return resposta
            resposta.raise_for_status()
            return resposta
        except requests.RequestException:
            if numero_tentativa == tentativas:
                raise
            time.sleep(espera_segundos * numero_tentativa)


def baixar_arquivo(url, destino):
    if destino.exists():
        return True
    destino.parent.mkdir(parents=True, exist_ok=True)
    resposta = requisitar_com_tentativas(url, stream=True, timeout=600)
    if resposta.status_code == 404:
        return False
    arquivo_temporario = destino.with_name(destino.name + ".parcial")
    with open(arquivo_temporario, "wb") as arquivo:
        for bloco in resposta.iter_content(chunk_size=1 << 20):
            arquivo.write(bloco)
    arquivo_temporario.rename(destino)
    return True


def baixar_primeira_extensao_disponivel(url_sem_extensao, destino_sem_extensao, extensoes=(".csv", ".zip")):
    for extensao in extensoes:
        destino = destino_sem_extensao.with_name(destino_sem_extensao.name + extensao)
        if baixar_arquivo(url_sem_extensao + extensao, destino):
            return destino
    return None
