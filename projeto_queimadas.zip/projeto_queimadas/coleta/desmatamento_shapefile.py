import zipfile

import geopandas as gpd
import pandas as pd

from configuracao import (
    ANO_FINAL_COMPLETO,
    ANO_INICIAL_ANALISE,
    ARQUIVO_MALHA_MUNICIPIOS,
    ARQUIVO_PRODES_MANUAL,
    PASTA_PRODES_SHAPEFILE,
    PROJECAO_AREA_EQUIVALENTE,
)

NOMES_POSSIVEIS_COLUNA_ANO = ("year", "ano")
NOMES_POSSIVEIS_COLUNA_CLASSE = ("main_class", "class_name", "classe")


def localizar_shapefile_prodes():
    for arquivo_zip in sorted(PASTA_PRODES_SHAPEFILE.glob("*.zip")):
        with zipfile.ZipFile(arquivo_zip) as conteudo_zip:
            camadas = [nome for nome in conteudo_zip.namelist() if nome.lower().endswith(".shp")]
        if camadas:
            return f"zip://{arquivo_zip.resolve().as_posix()}!{camadas[0]}"
    for arquivo_shp in sorted(PASTA_PRODES_SHAPEFILE.rglob("*.shp")):
        return str(arquivo_shp)
    return None


def encontrar_coluna_por_nome(colunas, nomes_possiveis):
    colunas_minusculas = {coluna.lower(): coluna for coluna in colunas}
    for nome in nomes_possiveis:
        if nome in colunas_minusculas:
            return colunas_minusculas[nome]
    return None


def carregar_malha_municipios_geografica():
    malha = gpd.read_file(ARQUIVO_MALHA_MUNICIPIOS)
    malha["codigo_ibge"] = malha["codarea"].astype(int)
    return malha[["codigo_ibge", "geometry"]]


def carregar_poligonos_desmatamento(caminho_shapefile, malha_municipios):
    poligonos = gpd.read_file(caminho_shapefile, bbox=malha_municipios)
    print(f"Poligonos lidos na area do Para: {len(poligonos)}")
    print(f"Colunas do shapefile: {list(poligonos.columns)}")
    coluna_ano = encontrar_coluna_por_nome(poligonos.columns, NOMES_POSSIVEIS_COLUNA_ANO)
    if coluna_ano is None:
        raise KeyError("Coluna de ano nao encontrada no shapefile.")
    poligonos["ano_prodes"] = pd.to_numeric(poligonos[coluna_ano], errors="coerce")
    poligonos = poligonos[poligonos["ano_prodes"].between(ANO_INICIAL_ANALISE, ANO_FINAL_COMPLETO)]
    coluna_classe = encontrar_coluna_por_nome(poligonos.columns, NOMES_POSSIVEIS_COLUNA_CLASSE)
    if coluna_classe is not None:
        print(f"Classes encontradas em '{coluna_classe}': {poligonos[coluna_classe].value_counts().to_dict()}")
        eh_desmatamento = poligonos[coluna_classe].astype(str).str.lower().str.startswith("desmat")
        if eh_desmatamento.any():
            poligonos = poligonos[eh_desmatamento]
        else:
            print("Nenhuma classe comeca com 'desmat'; todos os poligonos foram mantidos.")
    return poligonos[["ano_prodes", "geometry"]]


def calcular_desmatamento_por_municipio():
    caminho_shapefile = localizar_shapefile_prodes()
    if caminho_shapefile is None:
        return None
    malha_municipios = carregar_malha_municipios_geografica()
    poligonos = carregar_poligonos_desmatamento(caminho_shapefile, malha_municipios)
    poligonos = poligonos.to_crs(PROJECAO_AREA_EQUIVALENTE)
    malha_projetada = malha_municipios.to_crs(PROJECAO_AREA_EQUIVALENTE)
    poligonos["geometry"] = poligonos.geometry.make_valid()
    malha_projetada["geometry"] = malha_projetada.geometry.make_valid()
    intersecoes = gpd.overlay(poligonos, malha_projetada, how="intersection", keep_geom_type=True)
    intersecoes["desmatamento_km2"] = intersecoes.geometry.area / 1_000_000
    desmatamento_por_municipio = (
        intersecoes.groupby(["codigo_ibge", "ano_prodes"])["desmatamento_km2"].sum().reset_index()
    )
    grade_completa = pd.MultiIndex.from_product(
        [malha_municipios["codigo_ibge"], range(ANO_INICIAL_ANALISE, ANO_FINAL_COMPLETO + 1)],
        names=["codigo_ibge", "ano_prodes"],
    ).to_frame(index=False)
    desmatamento_por_municipio = grade_completa.merge(
        desmatamento_por_municipio, on=["codigo_ibge", "ano_prodes"], how="left"
    ).fillna({"desmatamento_km2": 0})
    print("Total do Para por ciclo (km2), para conferir com o TerraBrasilis:")
    print(desmatamento_por_municipio.groupby("ano_prodes")["desmatamento_km2"].sum().round(2).to_string())
    ARQUIVO_PRODES_MANUAL.parent.mkdir(parents=True, exist_ok=True)
    desmatamento_por_municipio.to_csv(ARQUIVO_PRODES_MANUAL, index=False)
    return desmatamento_por_municipio


if __name__ == "__main__":
    if calcular_desmatamento_por_municipio() is None:
        print(f"Nenhum shapefile encontrado em {PASTA_PRODES_SHAPEFILE}.")
