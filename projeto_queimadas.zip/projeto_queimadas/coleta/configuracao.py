from pathlib import Path

PASTA_DADOS_BRUTOS = Path("dados/brutos")
PASTA_DADOS_TRATADOS = Path("dados/tratados")

CODIGO_UF_PARA = 15
NOME_ESTADO_PARA = "PARA"

ANO_INICIAL_COLETA = 2014
ANO_INICIAL_ANALISE = 2015
ANO_FINAL_COMPLETO = 2025
ANO_PARCIAL = 2026
ULTIMO_MES_PARCIAL = 8
MES_INICIO_ANO_PRODES = 8

SATELITE_REFERENCIA = "AQUA_M-T"

LIMIAR_ANOMALIA_ENSO = 0.5
MINIMO_TRIMESTRES_CONSECUTIVOS_ENSO = 5

PARAMETROS_CLIMATICOS = ["T2M", "T2M_MAX", "PRECTOTCORR", "RH2M"]

URL_FOCOS_ANUAL = "https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/anual/Brasil/focos_anual_br_{ano}"
URL_FOCOS_MENSAL = "https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/mensal/Brasil/focos_mensal_br_{ano}{mes:02d}"
URL_MUNICIPIOS_IBGE = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/{uf}/municipios"
URL_METADADOS_MALHA_IBGE = "https://servicodados.ibge.gov.br/api/v3/malhas/municipios/{codigo}/metadados"
URL_MALHA_MUNICIPIOS_PARA = "https://servicodados.ibge.gov.br/api/v3/malhas/estados/{uf}"
ARQUIVO_MALHA_MUNICIPIOS = PASTA_DADOS_BRUTOS / "malha_municipios_para.geojson"
URL_NASA_POWER_DIARIO = "https://power.larc.nasa.gov/api/temporal/daily/point"
URL_ONI_NOAA = "https://www.cpc.ncep.noaa.gov/data/indices/oni.ascii.txt"

ARQUIVO_PRODES_MANUAL = PASTA_DADOS_BRUTOS / "prodes_municipios_para.csv"
PASTA_PRODES_SHAPEFILE = PASTA_DADOS_BRUTOS / "prodes_shapefile"
PROJECAO_AREA_EQUIVALENTE = "ESRI:102033"
