import re

import pandas as pd

from configuracao import ARQUIVO_PRODES_MANUAL

PADRAO_COLUNA_INCREMENTO_ANUAL = re.compile(r"incremento\D*(\d{4})", re.IGNORECASE)
PALAVRAS_COLUNA_CODIGO = ("ibge", "geocod", "cod_mun", "codmun", "id_municipio")
COLUNAS_FORMATO_PADRAO = ["codigo_ibge", "ano_prodes", "desmatamento_km2"]


def encontrar_coluna(colunas, palavras_chave):
    for palavra in palavras_chave:
        for coluna in colunas:
            if palavra in coluna.lower():
                return coluna
    raise KeyError(f"Nenhuma coluna contem {palavras_chave}. Colunas disponiveis: {list(colunas)}")


def carregar_desmatamento_anual_para():
    if not ARQUIVO_PRODES_MANUAL.exists():
        return None
    tabela_prodes = pd.read_csv(ARQUIVO_PRODES_MANUAL, sep=None, engine="python", encoding="utf-8-sig")
    if set(COLUNAS_FORMATO_PADRAO).issubset(tabela_prodes.columns):
        return tabela_prodes[COLUNAS_FORMATO_PADRAO].astype({"codigo_ibge": int, "ano_prodes": int})
    coluna_codigo = encontrar_coluna(tabela_prodes.columns, PALAVRAS_COLUNA_CODIGO)
    colunas_incremento = {
        coluna: int(correspondencia.group(1))
        for coluna in tabela_prodes.columns
        if (correspondencia := PADRAO_COLUNA_INCREMENTO_ANUAL.search(coluna))
    }
    if colunas_incremento:
        formato_longo = tabela_prodes.melt(
            id_vars=coluna_codigo,
            value_vars=list(colunas_incremento),
            var_name="coluna_origem",
            value_name="desmatamento_km2",
        )
        formato_longo["ano_prodes"] = formato_longo["coluna_origem"].map(colunas_incremento)
    else:
        coluna_ano = encontrar_coluna(tabela_prodes.columns, ("ano", "year"))
        coluna_area = encontrar_coluna(tabela_prodes.columns, ("incremento", "increment", "area"))
        formato_longo = tabela_prodes.rename(columns={coluna_ano: "ano_prodes", coluna_area: "desmatamento_km2"})
    formato_longo = formato_longo.rename(columns={coluna_codigo: "codigo_ibge"})
    formato_longo["desmatamento_km2"] = pd.to_numeric(
        formato_longo["desmatamento_km2"].astype(str).str.replace(",", ".", regex=False), errors="coerce"
    )
    return formato_longo[["codigo_ibge", "ano_prodes", "desmatamento_km2"]].astype({"codigo_ibge": int, "ano_prodes": int})
