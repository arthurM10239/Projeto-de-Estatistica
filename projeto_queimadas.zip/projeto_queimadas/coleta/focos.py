import pandas as pd

from configuracao import (
    ANO_FINAL_COMPLETO,
    ANO_INICIAL_COLETA,
    ANO_PARCIAL,
    NOME_ESTADO_PARA,
    PASTA_DADOS_BRUTOS,
    SATELITE_REFERENCIA,
    ULTIMO_MES_PARCIAL,
    URL_FOCOS_ANUAL,
    URL_FOCOS_MENSAL,
)
from utilidades import baixar_primeira_extensao_disponivel, normalizar_nome

APELIDOS_COLUNAS_FOCOS = {
    "data_hora_gmt": "data_hora",
    "datahora": "data_hora",
    "data_pas": "data_hora",
    "satelite": "satelite",
    "municipio": "municipio",
    "estado": "estado",
}

PASTA_FOCOS = PASTA_DADOS_BRUTOS / "focos"


def baixar_arquivos_focos():
    arquivos_baixados = []
    for ano in range(ANO_INICIAL_COLETA, ANO_FINAL_COMPLETO + 1):
        arquivo = baixar_primeira_extensao_disponivel(
            URL_FOCOS_ANUAL.format(ano=ano), PASTA_FOCOS / f"focos_anual_br_{ano}"
        )
        if arquivo is None:
            print(f"Arquivo anual de focos indisponivel: {ano}")
        else:
            arquivos_baixados.append(arquivo)
    for mes in range(1, ULTIMO_MES_PARCIAL + 1):
        arquivo = baixar_primeira_extensao_disponivel(
            URL_FOCOS_MENSAL.format(ano=ANO_PARCIAL, mes=mes), PASTA_FOCOS / f"focos_mensal_br_{ANO_PARCIAL}{mes:02d}"
        )
        if arquivo is None:
            print(f"Arquivo mensal de focos indisponivel: {ANO_PARCIAL}-{mes:02d}")
        else:
            arquivos_baixados.append(arquivo)
    return arquivos_baixados


def eh_coluna_de_interesse(nome_coluna):
    return nome_coluna.strip().lower() in APELIDOS_COLUNAS_FOCOS


def extrair_focos_referencia_para(caminho_arquivo):
    blocos_filtrados = []
    leitor = pd.read_csv(
        caminho_arquivo,
        usecols=eh_coluna_de_interesse,
        dtype=str,
        encoding="latin-1",
        chunksize=500_000,
    )
    for bloco in leitor:
        bloco.columns = [APELIDOS_COLUNAS_FOCOS[coluna.strip().lower()] for coluna in bloco.columns]
        bloco = bloco[bloco["satelite"].str.strip() == SATELITE_REFERENCIA]
        estados_normalizados = {estado: normalizar_nome(estado) for estado in bloco["estado"].dropna().unique()}
        bloco = bloco[bloco["estado"].map(estados_normalizados) == NOME_ESTADO_PARA]
        blocos_filtrados.append(bloco[["data_hora", "municipio"]])
    return pd.concat(blocos_filtrados, ignore_index=True)


def contar_focos_mensais_por_municipio(arquivos_focos, tabela_municipios, correcoes_nomes=None):
    focos_para = pd.concat([extrair_focos_referencia_para(arquivo) for arquivo in arquivos_focos], ignore_index=True)
    datas = pd.to_datetime(focos_para["data_hora"], errors="coerce")
    focos_para = focos_para.assign(ano=datas.dt.year, mes=datas.dt.month).dropna(subset=["ano"])
    focos_para["nome_normalizado"] = focos_para["municipio"].map(normalizar_nome).replace(correcoes_nomes or {})
    focos_com_codigo = focos_para.merge(
        tabela_municipios[["nome_normalizado", "codigo_ibge"]], on="nome_normalizado", how="left"
    )
    nomes_sem_correspondencia = sorted(focos_com_codigo.loc[focos_com_codigo["codigo_ibge"].isna(), "municipio"].unique())
    if nomes_sem_correspondencia:
        print("Municipios dos focos sem correspondencia no IBGE:", nomes_sem_correspondencia)
    contagem = (
        focos_com_codigo.dropna(subset=["codigo_ibge"])
        .groupby(["codigo_ibge", "ano", "mes"])
        .size()
        .rename("quantidade_focos")
        .reset_index()
    )
    return contagem.astype({"codigo_ibge": int, "ano": int, "mes": int})
