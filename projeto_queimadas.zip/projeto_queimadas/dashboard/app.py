import pandas as pd
import streamlit as st

from graficos import (
    grafico_distribuicao_por_fase,
    grafico_distribuicao_por_mes,
    grafico_evolucao_por_ciclo,
    grafico_mapa_municipios,
    grafico_relacao_clima_focos,
    grafico_relacao_desmatamento_focos,
    grafico_serie_temporal,
)
from preparacao import (
    METRICAS_FOCOS,
    NOMES_MESES,
    ORDEM_FASES_ENSO,
    VARIAVEIS_CLIMATICAS,
    agregar_por_ciclo_prodes,
    agregar_por_mes,
    agregar_por_municipio,
    calcular_desvio_da_media_do_mes,
    carregar_base_anual,
    carregar_base_mensal,
    carregar_malha_municipios,
    filtrar_base_anual,
    filtrar_base_mensal,
)

st.set_page_config(page_title="Focos de calor, clima e desmatamento no Pará", layout="wide")


def montar_filtros_laterais(base_mensal):
    st.sidebar.header("Filtros")
    ano_minimo, ano_maximo = int(base_mensal["ano"].min()), int(base_mensal["ano"].max())
    intervalo_anos = st.sidebar.slider("Período (anos)", ano_minimo, ano_maximo, (ano_minimo, ano_maximo))
    mes_inicial, mes_final = st.sidebar.select_slider(
        "Meses do ano", options=list(NOMES_MESES), value=(1, 12), format_func=NOMES_MESES.get
    )
    municipios_disponiveis = (
        base_mensal[["codigo_ibge", "nome_municipio"]].drop_duplicates().sort_values("nome_municipio")
    )
    nome_por_codigo = dict(zip(municipios_disponiveis["codigo_ibge"], municipios_disponiveis["nome_municipio"]))
    codigos_municipios = st.sidebar.multiselect(
        "Municípios", options=list(nome_por_codigo), format_func=nome_por_codigo.get, placeholder="Todos"
    )
    fases_enso = st.sidebar.multiselect("Fase do ENSO", ORDEM_FASES_ENSO, default=ORDEM_FASES_ENSO)
    rotulo_metrica = st.sidebar.radio("Medida de focos", list(METRICAS_FOCOS))
    return {
        "intervalo_anos": intervalo_anos,
        "intervalo_meses": (mes_inicial, mes_final),
        "codigos_municipios": codigos_municipios,
        "fases_enso": fases_enso or ORDEM_FASES_ENSO,
        "rotulo_metrica": rotulo_metrica,
        "coluna_metrica": METRICAS_FOCOS[rotulo_metrica],
    }


def exibir_indicadores(base_filtrada, agregado_mensal):
    area_total = base_filtrada.drop_duplicates("codigo_ibge")["area_km2"].sum()
    coluna_total, coluna_densidade, coluna_temperatura, coluna_chuva, coluna_meses = st.columns(5)
    coluna_total.metric("Total de focos", f"{int(agregado_mensal['quantidade_focos'].sum()):,}".replace(",", "."))
    coluna_densidade.metric(
        "Focos por 1000 km²", f"{agregado_mensal['quantidade_focos'].sum() / area_total * 1000:.1f}"
    )
    coluna_temperatura.metric(
        "Temperatura máxima média", f"{agregado_mensal['temperatura_maxima_media_c'].mean():.1f} °C"
    )
    coluna_chuva.metric("Precipitação média mensal", f"{agregado_mensal['precipitacao_total_mm'].mean():.0f} mm")
    coluna_meses.metric("Meses no recorte", len(agregado_mensal))


def exibir_aba_mensal(base_filtrada, filtros):
    agregado_mensal = agregar_por_mes(base_filtrada)
    coluna_metrica, rotulo_metrica = filtros["coluna_metrica"], filtros["rotulo_metrica"]
    exibir_indicadores(base_filtrada, agregado_mensal)

    st.plotly_chart(grafico_serie_temporal(agregado_mensal, coluna_metrica, rotulo_metrica), width="stretch")

    coluna_esquerda, coluna_direita = st.columns(2)
    coluna_esquerda.plotly_chart(
        grafico_distribuicao_por_mes(agregado_mensal, coluna_metrica, rotulo_metrica), width="stretch"
    )
    coluna_direita.plotly_chart(
        grafico_distribuicao_por_fase(agregado_mensal, coluna_metrica, rotulo_metrica), width="stretch"
    )

    coluna_controles, coluna_grafico = st.columns([1, 3])
    coluna_clima = coluna_controles.selectbox(
        "Variável climática", list(VARIAVEIS_CLIMATICAS), format_func=VARIAVEIS_CLIMATICAS.get
    )
    forma_valores = coluna_controles.radio("Valores", ["Originais", "Desvio da média do mês do ano"])
    tabela_relacao = agregado_mensal
    rotulo_clima = VARIAVEIS_CLIMATICAS[coluna_clima]
    rotulo_focos_relacao = rotulo_metrica
    if forma_valores != "Originais":
        tabela_relacao = calcular_desvio_da_media_do_mes(agregado_mensal, [coluna_clima, coluna_metrica])
        rotulo_clima = f"Desvio: {rotulo_clima}"
        rotulo_focos_relacao = f"Desvio: {rotulo_metrica}"
    correlacao_spearman = tabela_relacao[[coluna_clima, coluna_metrica]].corr(method="spearman").iloc[0, 1]
    texto_correlacao = "—" if pd.isna(correlacao_spearman) else f"{correlacao_spearman:.2f}"
    coluna_controles.metric("Correlação de Spearman", texto_correlacao)
    coluna_controles.metric("Pares de valores", int(tabela_relacao[[coluna_clima, coluna_metrica]].dropna().shape[0]))
    coluna_grafico.plotly_chart(
        grafico_relacao_clima_focos(tabela_relacao, coluna_clima, rotulo_clima, coluna_metrica, rotulo_focos_relacao),
        width="stretch",
    )

    malha = carregar_malha_municipios()
    if malha is not None:
        st.plotly_chart(
            grafico_mapa_municipios(agregar_por_municipio(base_filtrada), malha, coluna_metrica, rotulo_metrica),
            width="stretch",
        )


def exibir_aba_anual(base_anual, filtros):
    st.caption("Filtros aplicados nesta aba: período (ciclo PRODES) e municípios.")
    base_anual_filtrada = filtrar_base_anual(base_anual, filtros["intervalo_anos"], filtros["codigos_municipios"])
    if base_anual_filtrada.empty:
        st.warning("Nenhum dado para os filtros selecionados.")
        return
    st.plotly_chart(grafico_evolucao_por_ciclo(agregar_por_ciclo_prodes(base_anual_filtrada)), width="stretch")
    usar_escala_logaritmica = st.toggle("Escala logarítmica")
    st.plotly_chart(
        grafico_relacao_desmatamento_focos(base_anual_filtrada, usar_escala_logaritmica), width="stretch"
    )


def executar_dashboard():
    st.title("Focos de calor, clima e desmatamento no Pará")
    base_mensal = carregar_base_mensal()
    filtros = montar_filtros_laterais(base_mensal)
    base_filtrada = filtrar_base_mensal(
        base_mensal, filtros["intervalo_anos"], filtros["intervalo_meses"],
        filtros["codigos_municipios"], filtros["fases_enso"],
    )
    aba_mensal, aba_anual = st.tabs(["Mensal", "Anual (ciclo PRODES)"])
    with aba_mensal:
        if base_filtrada.empty:
            st.warning("Nenhum dado para os filtros selecionados.")
        else:
            exibir_aba_mensal(base_filtrada, filtros)
    with aba_anual:
        base_anual = carregar_base_anual()
        if base_anual is None:
            st.warning("Base anual não encontrada.")
        else:
            exibir_aba_anual(base_anual, filtros)
    st.caption("Fontes: INPE (BDQueimadas, satélite de referência AQUA_M-T; PRODES), NASA POWER, NOAA CPC (ONI), IBGE.")


executar_dashboard()
