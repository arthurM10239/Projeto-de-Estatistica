import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from preparacao import NOMES_MESES, ORDEM_FASES_ENSO

CORES_FASES_ENSO = {"La Niña": "#2c7fb8", "Neutro": "#9e9e9e", "El Niño": "#d95f0e"}
ORDEM_NOMES_MESES = list(NOMES_MESES.values())


def grafico_serie_temporal(agregado_mensal, coluna_focos, rotulo_focos):
    figura = go.Figure()
    figura.add_trace(go.Scatter(
        x=agregado_mensal["data"], y=agregado_mensal[coluna_focos],
        mode="lines", line={"color": "#bdbdbd", "width": 1}, showlegend=False, hoverinfo="skip",
    ))
    for fase in ORDEM_FASES_ENSO:
        pontos_da_fase = agregado_mensal[agregado_mensal["fase_enso"] == fase]
        figura.add_trace(go.Scatter(
            x=pontos_da_fase["data"], y=pontos_da_fase[coluna_focos],
            mode="markers", name=fase, marker={"color": CORES_FASES_ENSO[fase], "size": 7},
        ))
    figura.update_layout(
        title="Focos de calor por mês e fase do ENSO",
        xaxis_title="Mês", yaxis_title=rotulo_focos, legend_title="Fase do ENSO",
    )
    return figura


def grafico_distribuicao_por_mes(agregado_mensal, coluna_focos, rotulo_focos):
    figura = px.box(
        agregado_mensal, x="nome_mes", y=coluna_focos, points="all", hover_data=["ano"],
        category_orders={"nome_mes": ORDEM_NOMES_MESES},
        labels={"nome_mes": "Mês do ano", coluna_focos: rotulo_focos},
        title="Distribuição dos focos por mês do ano",
    )
    return figura


def grafico_distribuicao_por_fase(agregado_mensal, coluna_focos, rotulo_focos):
    figura = px.box(
        agregado_mensal, x="fase_enso", y=coluna_focos, color="fase_enso", points="all",
        hover_data=["ano", "nome_mes"],
        category_orders={"fase_enso": ORDEM_FASES_ENSO}, color_discrete_map=CORES_FASES_ENSO,
        labels={"fase_enso": "Fase do ENSO", coluna_focos: rotulo_focos},
        title="Distribuição dos focos mensais por fase do ENSO",
    )
    figura.update_layout(showlegend=False)
    return figura


def grafico_relacao_clima_focos(tabela, coluna_clima, rotulo_clima, coluna_focos, rotulo_focos):
    figura = px.scatter(
        tabela, x=coluna_clima, y=coluna_focos, color="fase_enso", hover_data=["ano", "nome_mes"],
        category_orders={"fase_enso": ORDEM_FASES_ENSO}, color_discrete_map=CORES_FASES_ENSO,
        labels={coluna_clima: rotulo_clima, coluna_focos: rotulo_focos, "fase_enso": "Fase do ENSO"},
        title=f"{rotulo_clima} e focos de calor por mês",
    )
    return figura


def grafico_mapa_municipios(agregado_municipios, malha, coluna_focos, rotulo_focos):
    figura = px.choropleth(
        agregado_municipios, geojson=malha, locations="codigo_ibge_texto",
        featureidkey="properties.codarea", color=coluna_focos, color_continuous_scale="YlOrRd",
        hover_name="nome_municipio", hover_data={"codigo_ibge_texto": False, "quantidade_focos": True},
        labels={coluna_focos: rotulo_focos, "quantidade_focos": "Quantidade de focos"},
        title="Focos de calor por município no recorte selecionado",
    )
    figura.update_geos(fitbounds="locations", visible=False)
    figura.update_layout(height=600, margin={"l": 0, "r": 0, "t": 50, "b": 0})
    return figura


def grafico_relacao_desmatamento_focos(base_anual_filtrada, usar_escala_logaritmica):
    tabela = base_anual_filtrada.dropna(subset=["desmatamento_pct_area"])
    if usar_escala_logaritmica:
        tabela = tabela[(tabela["desmatamento_pct_area"] > 0) & (tabela["focos_por_1000_km2"] > 0)]
    figura = px.scatter(
        tabela, x="desmatamento_pct_area", y="focos_por_1000_km2", color="ano_prodes",
        hover_name="nome_municipio", log_x=usar_escala_logaritmica, log_y=usar_escala_logaritmica,
        color_continuous_scale="Viridis",
        labels={
            "desmatamento_pct_area": "Desmatamento no ciclo (% da área do município)",
            "focos_por_1000_km2": "Focos por 1000 km²",
            "ano_prodes": "Ciclo PRODES",
        },
        title="Desmatamento e focos de calor por município e ciclo PRODES",
    )
    return figura


def grafico_evolucao_por_ciclo(agregado_ciclos):
    figura = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.08,
        subplot_titles=("Desmatamento (km²)", "Focos de calor"),
    )
    figura.add_trace(go.Bar(
        x=agregado_ciclos["ano_prodes"], y=agregado_ciclos["desmatamento_km2"],
        name="Desmatamento (km²)", marker_color="#31a354",
    ), row=1, col=1)
    figura.add_trace(go.Bar(
        x=agregado_ciclos["ano_prodes"], y=agregado_ciclos["quantidade_focos"],
        name="Focos de calor", marker_color="#e6550d",
    ), row=2, col=1)
    figura.update_layout(
        title="Desmatamento e focos de calor por ciclo PRODES (agosto a julho)",
        showlegend=False, height=550,
    )
    figura.update_xaxes(title_text="Ciclo PRODES", dtick=1, row=2, col=1)
    return figura
